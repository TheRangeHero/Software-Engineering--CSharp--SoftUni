﻿namespace ChristmasPastryShop.Core
{
    internal interface IBoothRepository<T>
    {
    }
}