﻿namespace Raiding.Core.Interfaces
{
    interface IEngine
    {
        void Run();
    }
}
