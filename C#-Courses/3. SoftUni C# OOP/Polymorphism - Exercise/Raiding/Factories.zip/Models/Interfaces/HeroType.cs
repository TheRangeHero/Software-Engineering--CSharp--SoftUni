﻿namespace Raiding.Models.Interfaces
{
    public enum HeroType
    {
        Druid = 1,
        Paladin = 2,
        Rogue = 3,
        Warrior = 4
    }
}
