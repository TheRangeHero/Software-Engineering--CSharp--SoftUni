﻿namespace Raiding.Models.Interfaces
{
    public enum HerosPowers
    {
        Druid = 80,
        Paladin = 100,
        Rogue = 80,
        Warrior = 100
    }
}
