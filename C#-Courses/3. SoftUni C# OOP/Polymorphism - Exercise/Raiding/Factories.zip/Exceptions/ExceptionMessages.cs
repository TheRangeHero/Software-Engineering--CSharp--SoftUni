﻿namespace Raiding.Exceptions
{
    class ExceptionMessages
    {
        public const string INVALID_HERO_iNPUT_EXCEPTION = "Invalid hero!";
    }
}
