﻿namespace Raiding.IO.Interfaces
{
    interface IReader
    {
        string ReadLine();
    }
}
