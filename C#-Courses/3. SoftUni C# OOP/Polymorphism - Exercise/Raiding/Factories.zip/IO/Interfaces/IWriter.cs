﻿namespace Raiding.IO.Interfaces
{
    interface IWriter
    {
        void Write(object value);
        void WirteLine(object value);
    }
}
