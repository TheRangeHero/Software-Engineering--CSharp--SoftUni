﻿namespace P01.ClassBoxData
{
    public static class ExceptionMessages
    {
        public const string BoxParameterCannotBeZeroOrNegative =
            "{0} cannot be zero or negative.";
    }
}