﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleSnake.Core
{
using SimpleSnake.Core.Contracts;
    using SimpleSnake.Enums;
    using SimpleSnake.GameObjects;

    class Engine : IEngine
    {
        private Point[] directionPoints;
        private Direction direction;


        public void Run()
        {
            throw new NotImplementedException();
        }


        private void GetDirectionPoints()
        {
            this.directionPoints[(int)Direction.Right] = new Point(1, 0);
            this.directionPoints[(int)Direction.Left] = new Point(-1, 0);
            this.directionPoints[(int)Direction.Down] = new Point(0, 1);
            this.directionPoints[(int)Direction.Up] = new Point(0, -1);
        }

        private void GetNextDirection()
        {
            ConsoleKeyInfo userInput = Console.ReadKey();

            if (userInput.Key==ConsoleKey.LeftArrow)
            {
                if (this.direction!=Direction.Right)
                {
                    this.direction = Direction.Left;
                }
            }
            else if (userInput.Key==ConsoleKey.RightArrow)
            {
                if (this.direction!=Direction.Left)
                {
                    this.direction = Direction.Right;
                }
            }
            else if (userInput.Key == ConsoleKey.UpArrow)
            {
                if (this.direction !=Direction.Down)
                {
                    this.direction = Direction.Up;
                }
            }
            else if (userInput.Key == ConsoleKey.DownArrow)
            {
                if (this.direction !=Direction.Up)
                {
                    this.direction = Direction.Down;
                }
            }
        }
    }
}
