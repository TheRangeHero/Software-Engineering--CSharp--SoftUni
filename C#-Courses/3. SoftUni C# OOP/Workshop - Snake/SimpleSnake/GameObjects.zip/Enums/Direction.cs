﻿namespace SimpleSnake.Enums
{
    public enum Direction
    {
        Right = 0,
        Left = 1,
        Down = 2,
        Up = 3,
    }
}
