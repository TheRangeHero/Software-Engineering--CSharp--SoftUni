﻿namespace BorderControl.IO.Interfaces
{
    interface IReader
    {
        string ReadLine();
    }
}
