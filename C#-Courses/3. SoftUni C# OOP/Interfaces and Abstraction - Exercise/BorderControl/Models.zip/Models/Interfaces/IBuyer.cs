﻿public interface IBuyer
{

    int Food { get; }
    public string Name { get;}
    void BuyFood();
}