﻿namespace BorderControl.Models.Interfaces
{
    interface ILivingcreatures
    {
        public string Name { get; }

        public string BirthDate { get; }

    }
}
