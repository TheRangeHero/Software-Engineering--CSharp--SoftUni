﻿namespace BorderControl.Models
{
    class Pet : LivingBeing
    {
        public Pet(string name, string birthDate) : base(name, birthDate)
        {
        }
    }
}
