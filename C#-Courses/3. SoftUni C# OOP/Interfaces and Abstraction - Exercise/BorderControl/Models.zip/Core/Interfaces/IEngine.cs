﻿namespace BorderControl.Core.Interfaces
{
    interface IEngine
    {
        void Run();
    }
}
