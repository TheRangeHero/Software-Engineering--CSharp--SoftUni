﻿namespace Telephony.IO
{
    using Interfaces;
  public  class FileWriter : IWriter
    {
        public void Write(string text)
        {
            throw new System.NotImplementedException();
        }

        public void WriteLine(string text)
        {
            throw new System.NotImplementedException();
        }
    }
}
