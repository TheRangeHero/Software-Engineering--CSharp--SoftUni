﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=DESKTOP-FD3TR9V\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
