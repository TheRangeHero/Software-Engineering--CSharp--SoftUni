﻿namespace P01_StudentSystem.Data.Common;

public class DbConfig
{
    public const string Connection_String = @"Server=localhost\SQLEXPRESS;Database=Bet388;Integrated Security=True;Encrypt=False";
}