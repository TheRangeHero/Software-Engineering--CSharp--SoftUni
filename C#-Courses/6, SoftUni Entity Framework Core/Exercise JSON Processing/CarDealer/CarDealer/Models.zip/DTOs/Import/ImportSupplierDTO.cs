﻿namespace CarDealer.DTOs.Import;

public class ImportSupplierDTO
{
    public string Name { get; set; } = null!;

    public bool IsImporter { get; set; }
}
