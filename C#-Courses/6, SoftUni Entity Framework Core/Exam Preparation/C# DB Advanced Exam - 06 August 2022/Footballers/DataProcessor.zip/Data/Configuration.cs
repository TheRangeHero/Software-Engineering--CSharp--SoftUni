﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=FootballersExam;Trusted_Connection=True";
    }
}
