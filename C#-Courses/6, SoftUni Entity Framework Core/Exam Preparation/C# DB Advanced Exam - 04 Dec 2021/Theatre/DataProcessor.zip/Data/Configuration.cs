﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=Theatre;Integrated Security=True;Encrypt=False";
    }
}
