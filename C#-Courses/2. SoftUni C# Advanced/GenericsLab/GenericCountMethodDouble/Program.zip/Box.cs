﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCountMethodDouble
{
   public class Box<T> where T : IComparable
    {
        public List<T> ListOfDouble { get; set; }

        public Box()
        {
            ListOfDouble = new List<T>();
        }

        public int Count (T itemToCompare)
        {
            int count = 0;

            foreach (var item in ListOfDouble)
            {
                if (item.CompareTo(itemToCompare)>0)
                {
                    count++;
                }
            }
            return count;
        }
    }
}
